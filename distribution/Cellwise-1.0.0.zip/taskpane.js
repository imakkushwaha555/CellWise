"use strict";
(() => {
  // src/formula.ts
  function colToIndex(col) {
    let n = 0;
    for (const ch of col.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
    return n - 1;
  }
  function indexToCol(i) {
    let s = "";
    for (i += 1; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + (i - 1) % 26) + s;
    return s;
  }
  var addressOf = (row, col) => `${indexToCol(col)}${row + 1}`;
  function parseAddress(address) {
    const match = /^([A-Za-z]+)([1-9]\d*)$/.exec(address);
    if (!match) throw new Error(`Invalid cell address '${address}'`);
    const col = colToIndex(match[1]);
    const row = Number(match[2]) - 1;
    if (!Number.isSafeInteger(col) || col < 0 || !Number.isSafeInteger(row)) {
      throw new Error(`Invalid cell address '${address}'`);
    }
    return { row, col };
  }
  function tokenize(src) {
    const out = [];
    const re = /\s*(?:(\d+\.?\d*|\.\d+)|([A-Za-z]+\d+:[A-Za-z]+\d+)|([A-Za-z]+\d+)(?![A-Za-z(])|([A-Za-z_]+)|([+\-*/^()%,]))/y;
    let m;
    let pos = 0;
    while (pos < src.length) {
      re.lastIndex = pos;
      m = re.exec(src);
      if (!m) {
        if (src.slice(pos).trim() === "") break;
        throw new Error(`Unexpected '${src.slice(pos).trim()[0]}'`);
      }
      pos = re.lastIndex;
      if (m[1]) out.push({ t: "num", v: m[1] });
      else if (m[2]) out.push({ t: "range", v: m[2] });
      else if (m[3]) out.push({ t: "ref", v: m[3] });
      else if (m[4]) out.push({ t: "id", v: m[4].toUpperCase() });
      else if (m[5] === "(") out.push({ t: "(", v: "(" });
      else if (m[5] === ")") out.push({ t: ")", v: ")" });
      else if (m[5] === ",") out.push({ t: ",", v: "," });
      else out.push({ t: "op", v: m[5] });
    }
    return out;
  }
  var FUNCS = {
    SUM: (a) => a.reduce((x, y) => x + y, 0),
    AVERAGE: (a) => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0,
    MIN: (a) => Math.min(...a),
    MAX: (a) => Math.max(...a),
    COUNT: (a) => a.length,
    ABS: (a) => Math.abs(a[0]),
    ROUND: (a) => {
      const d = a[1] ?? 0;
      const f = 10 ** d;
      return Math.round(a[0] * f) / f;
    }
  };
  function evaluate(formula, grid) {
    const toks = tokenize(formula.replace(/^=/, ""));
    let p = 0;
    const peek = () => toks[p];
    const next = () => toks[p++];
    const cell = (ref) => {
      const { row, col } = parseAddress(ref);
      return grid[row]?.[col] ?? 0;
    };
    const range = (r) => {
      const [a, b] = r.split(":");
      const start = parseAddress(a);
      const end = parseAddress(b);
      const [c1, c2] = [start.col, end.col].sort((x, y) => x - y);
      const [r1, r2] = [start.row, end.row].sort((x, y) => x - y);
      const vals = [];
      const lastRow = Math.min(r2, grid.length - 1);
      const columnCount = grid.reduce((max, row) => Math.max(max, row.length), 0);
      const lastColumn = Math.min(c2, columnCount - 1);
      if (r1 > lastRow || c1 > lastColumn) return vals;
      for (let i = r1; i <= lastRow; i++) {
        for (let j = c1; j <= lastColumn; j++) {
          const value = grid[i]?.[j];
          if (value != null) vals.push(value);
        }
      }
      return vals;
    };
    function expr() {
      let v = term();
      while (peek()?.t === "op" && (peek().v === "+" || peek().v === "-")) v = next().v === "+" ? v + term() : v - term();
      return v;
    }
    function term() {
      let v = power();
      while (peek()?.t === "op" && (peek().v === "*" || peek().v === "/")) {
        const op = next().v;
        const r = power();
        if (op === "/" && r === 0) throw new Error("Division by zero");
        v = op === "*" ? v * r : v / r;
      }
      return v;
    }
    function power() {
      const b = unary();
      if (peek()?.t === "op" && peek().v === "^") {
        next();
        return b ** power();
      }
      return b;
    }
    function unary() {
      if (peek()?.t === "op" && (peek().v === "-" || peek().v === "+")) return next().v === "-" ? -unary() : unary();
      let v = atom();
      while (peek()?.t === "op" && peek().v === "%") {
        next();
        v /= 100;
      }
      return v;
    }
    function atom() {
      const t = next();
      if (!t) throw new Error("Unexpected end");
      if (t.t === "num") return parseFloat(t.v);
      if (t.t === "ref") return cell(t.v);
      if (t.t === "(") {
        const v = expr();
        if (next()?.t !== ")") throw new Error("Missing )");
        return v;
      }
      if (t.t === "id") {
        const fn = FUNCS[t.v];
        if (!fn) throw new Error(`Unknown function ${t.v}`);
        if (next()?.t !== "(") throw new Error("Expected (");
        const args = [];
        while (peek() && peek().t !== ")") {
          if (peek().t === "range") args.push(...range(next().v));
          else args.push(expr());
          if (peek()?.t === ",") next();
        }
        if (next()?.t !== ")") throw new Error("Missing )");
        return fn(args);
      }
      throw new Error(`Unexpected '${t.v}'`);
    }
    const result = expr();
    if (p < toks.length) throw new Error(`Unexpected '${toks[p].v}'`);
    return result;
  }

  // src/wordClient.ts
  function toGrid(values) {
    return values.map((r) => r.map((v) => {
      const n = parseFloat(String(v).replace(/[,\s$€£]/g, ""));
      return isNaN(n) ? null : n;
    }));
  }
  function formatResult(v) {
    return String(Math.round(v * 1e10) / 1e10);
  }
  async function computeCell(formula, grid) {
    try {
      const v = evaluate(formula, grid);
      return { value: v, error: null };
    } catch (e) {
      return { value: 0, error: e?.message ?? String(e) };
    }
  }

  // src/taskpane.ts
  var TAG = "fx:";
  var $ = (id) => document.getElementById(id);
  var setStatus = (msg, err = false) => {
    $("status").textContent = msg;
    $("status").className = err ? "err" : "";
  };
  var lastSelectionTimer = null;
  var DEBOUNCE_MS = 300;
  async function run(fn) {
    try {
      await Word.run(fn);
    } catch (e) {
      setStatus(e?.message ?? String(e), true);
    }
  }
  async function applyFormula(ctx) {
    if (!Office.context.requirements.isSetSupported("WordApi")) {
      return setStatus("This add-in requires WordApi 1.3. Your version does not support it.", true);
    }
    const formula = $("formula");
    const formulaText = formula.value.trim();
    if (!formulaText.startsWith("=")) return setStatus("Formula must start with =", true);
    const cell = ctx.document.getSelection().parentTableCellOrNullObject;
    const table = ctx.document.getSelection().parentTableOrNullObject;
    cell.load("isNullObject,rowIndex,cellIndex");
    table.load("isNullObject,values");
    await ctx.sync();
    if (cell.isNullObject || table.isNullObject) {
      return setStatus("Place the cursor inside a table cell.", true);
    }
    const result = await computeCell(formulaText, toGrid(table.values ?? []));
    if (result.error) {
      return setStatus(`Formula error: ${result.error}`, true);
    }
    const text = formatResult(result.value);
    const ccs = cell.body.contentControls;
    ccs.load("items/tag");
    await ctx.sync();
    const existing = ccs.items.find((c) => c.tag.startsWith(TAG));
    if (existing) {
      existing.tag = TAG + formulaText;
      existing.insertText(text, "Replace");
    } else {
      const cc = cell.body.getRange("Content").insertContentControl("PlainText");
      cc.tag = TAG + formulaText;
      cc.title = "Formula";
      cc.insertText(text, "Replace");
    }
    await ctx.sync();
    setStatus(`${addressOf(cell.rowIndex, cell.cellIndex)} ${formulaText} = ${text}`);
  }
  async function recalcTable(ctx) {
    if (!Office.context.requirements.isSetSupported("WordApi")) {
      return setStatus("This add-in requires WordApi 1.3. Your version does not support it.", true);
    }
    const table = ctx.document.getSelection().parentTableOrNullObject;
    table.load("isNullObject,values");
    await ctx.sync();
    if (table.isNullObject) return setStatus("Place the cursor inside a table.", true);
    const ccs = table.getRange().contentControls;
    ccs.load("items/tag");
    await ctx.sync();
    const fx = ccs.items.filter((c) => c.tag.startsWith(TAG));
    const cells = fx.map((c) => {
      const tc = c.parentTableCell;
      tc.load("rowIndex,cellIndex");
      return tc;
    });
    await ctx.sync();
    const grid = toGrid(table.values);
    const errors = [];
    for (let pass = 0; pass < fx.length + 1; pass++) {
      fx.forEach((c, i) => {
        try {
          grid[cells[i].rowIndex][cells[i].cellIndex] = evaluate(c.tag.slice(TAG.length), grid);
        } catch {
        }
      });
    }
    fx.forEach((c, i) => {
      try {
        const v = evaluate(c.tag.slice(TAG.length), grid);
        c.insertText(String(Math.round(v * 1e10) / 1e10), "Replace");
      } catch (e) {
        errors.push(`${addressOf(cells[i].rowIndex, cells[i].cellIndex)}: ${e.message}`);
        c.insertText("#ERR", "Replace");
      }
    });
    await ctx.sync();
    setStatus(
      errors.length ? errors.join("; ") : `Recalculated ${fx.length} formula(s).`,
      errors.length > 0
    );
  }
  Office.onReady(() => {
    $("apply").onclick = () => run(applyFormula);
    $("recalc").onclick = () => run(recalcTable);
    Office.context.document.addHandlerAsync(Office.EventType.DocumentSelectionChanged, () => {
      if (lastSelectionTimer) clearTimeout(lastSelectionTimer);
      lastSelectionTimer = setTimeout(() => run(showSelection), DEBOUNCE_MS);
    });
    run(showSelection);
  });
  async function showSelection(ctx) {
    const selection = ctx.document.getSelection();
    const cell = selection.parentTableCellOrNullObject;
    cell.load("isNullObject,rowIndex,cellIndex");
    await ctx.sync();
    $("addr").textContent = cell.isNullObject ? "\u2014" : addressOf(cell.rowIndex, cell.cellIndex);
  }
})();
